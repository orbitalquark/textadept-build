#pragma once

#include <stdint.h>

int64_t now(void);
